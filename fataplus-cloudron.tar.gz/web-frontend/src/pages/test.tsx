export default function Test() {
  return (
    <div>
      <h1>Test Page</h1>
      <p>This is a simple test page.</p>
    </div>
  );
}

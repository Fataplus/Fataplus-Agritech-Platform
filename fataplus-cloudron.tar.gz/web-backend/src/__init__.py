# Fataplus Web Backend
# Multi-context SaaS platform for African agriculture

__version__ = "1.0.0"
__author__ = "Fataplus Team"

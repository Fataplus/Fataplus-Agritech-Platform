```
http://www.indabaxmada.com
indabaxmadagascar@gmail.com
```
**Site web
Email**

### Sponsoring

### IndabaX

### Madagascar

### 2025

**L'IA en action pour**

**révolutionner l'éducation et**

**la science à Madagascar.**

**19 - 20 - 21 Septembre 2025**


## Sommaire

**03.**

**06.**

**09.**

**04.**

**08.**

**07.**

**10.**

**À PROPOS**

**PROGRAMME ÉDITION 2025**

**PRÉVISIONS DES BESOINS**

**BILAN INDABAX MADAGASCAR 2024**

**OPPORTUNITÉS DE SPONSORING**

**PUBLIC CIBLE ET IMPACT ATTENDU**

**ÉQUIPE ORGANISATRICE**


```
Progrès sur le Machine Learning et
l’IA à Madagascar
```
**Sponsoring - IndabaX Madagascar 2025**

###### À propos d'IndabaX

###### Madagascar

```
La conférence IndabaX, initiée en 2018, est un programme conçu pour
encourager le partage d’expériences et de savoirs entre chercheurs dans les
domaines de l’intelligence artificielle, de l’apprentissage automatique et de
l’apprentissage profond. IndabaX vise à mobiliser davantage de personnes
pour contribuer à l’essor de l’intelligence artificielle sur notre continent. À ce
jour, 25 pays organisent chaque année des événements IndabaX.
Deep Learning Indaba
Le Deep Learning Indaba est une initiative panafricaine destinée à renforcer
les capacités et à promouvoir l’apprentissage automatique et l’intelligence
artificielle à travers l’Afrique. C’est une conférence annuelle dont le but
principal est de réunir des chercheurs, des praticiens et des passionnés d’IA
pour partager leurs connaissances, établir des collaborations et stimuler le
progrès de ces technologies sur le continent.
```
```
Vision Mission
Mettre en avant les solutions ML et IA
dans les secteurs clés au
Les malagasy soient de vrais développement de Madagascar
acteurs et architectes des
avancées technologiques
```
```
Encourager les recherches
locaux
Partage d’éxperience et savoir
```
```
3
```
```
L’importance d’IndabaX réside dans sa capacité à unifier et à renforcer la
communauté africaine autour de l’IA et de l’apprentissage automatique. En
soutenant chaque année des événements dans un nombre croissant de pays,
IndabaX contribue non seulement à l’enrichissement des compétences
locales, mais aussi à la formation d’une véritable communauté panafricaine
de chercheurs et de professionnels, favorisant l’innovation et les progrès
technologiques en Afrique.
```

**Sponsoring - IndabaX Madagascar 2025 4**

#### Bilan

#### IndabaX

#### Madagascar

#### 2024

```
Chaque année, nous unissons nos efforts
avec différentes entités pour assurer la
mise en œuvre et l'organisation de
l'événement.
Durant cette édition, nous avons choisi de
collaborer avec des instituts et des
universités spécialisés en informatique, ce
qui nous a permis de travailler avec l’UST-
IO, une université dédiée aux sciences et
technologies.
Nous avons également pu bénéficier du
soutien d'autres partenaires, tels que le
LIAM (Laboratoire d'Intelligence Artificielle
de Madagascar), We R Madagascar et
AMLD Africa.
Nous avons eu environ 150 personnes
inscrites par jour pour assister à
l’événement avec au total 9 Keynotes, 5
Workshops, 1 Hackathon, 1 Ideathon et 1
Poster durant les 3 Jours.
```
**Event**

```
Highlight
Recherches prometteurs et
avancés en IA dans les
secteurs clés de l'énergie
```
```
Mise en lumière des recherches
et idées innovants dans la
climatologie
```
```
Fédérateur des communautés
locaux autour du Data Science,
Machine Learning et IA
```
```
Idéathons créatifs pour des
solutions efficaces avec l'IA
dans l'agriculture
```

**Quelques clichés de**

**l’IndabaX Madagascar 2024**


**Sponsoring - IndabaX Madagascar 2025**

## Programme

## Édition 2025

```
Pour l'année 2025, le thème central sera “L’IA en action
pour révolutionner l'éducation et la science à
Madagascar.”
```
```
L'événement est prévu pour le vendredi 19, samedi 20 et
dimanche 21 septembre 2025. (Lieu à confirmer)
```
```
Le programme comprend des interventions lors de
keynotes, animés par divers experts en Intelligence
Artificielle.
```
```
En outre, des ateliers pratiques, un hackathon ainsi qu'un
ideathon seront proposés aux participants.
```
```
Toutes ces activités seront centrées sur des sujets divers
étroitement liés au développement de Madagascar grâce
à l’IA dans les domaines de l’éducation et de la science.
```
**19**

**20**

**SEP**

**SEP**

```
21
SEP
```
```
6
```

```
Profils participants attendu deNombre
participants
```
```
Retombées prévues pour la
communauté IA à Madagascar
```
```
Étudiants
Chercheurs
Data Scientists
Professionnels
dans
l’intelligence
artificielle
```
```
1.
```
```
Augmentation de l’intérêts pour le
Machine Learning et l'IA
Appropriation du Machine Learning
par les ingénieurs et chercheurs
malagasy
Mise en lumière des innovations
locaux
Augmentation des solutions IA
centrés sur les secteurs clés aux
développement du pays
```
**Sponsoring - IndabaX Madagascar 2025**

## Public cible et

## impact attendu

```
7
```

**Sponsoring - IndabaX Madagascar 2025**

```
Nous offrirons à nos sponsors une visibilité accrue à travers une
communication ciblée avant, pendant et après l'événement. Cela
inclura des publications sur nos réseaux sociaux, des newsletters et
des mises à jour sur notre site web, assurant ainsi une exposition
continue tout au long du processus.
```
```
Les logos et les informations des sponsors seront intégrés sur tous
nos supports de communication, y compris les affiches, brochures et
sites web. Cette visibilité permettra de mettre en avant les sponsors
auprès de tous les participants et intervenants, garantissant une
reconnaissance optimale de leur marque.
```
```
Nos sponsors bénéficieront d'opportunités exclusives de
networking lors de l'événement, avec un accès privilégié à des
sessions de réseautage, des tables rondes. Cela leur permettra
d'établir des connexions précieuses avec des professionnels et des
experts du secteur, favorisant ainsi des collaborations potentielles à
long terme.
```
**Communication avant, pendant et après l'événement**

**Présence sur les supports de communication**

**Opportunités de networking**

## Opportunités

## de sponsoring

```
Pour avoir un événement réussi nous avons besoin du
soutien de partenaires et sponsors.
```
```
8
```
```
Ce que nous offrons en retour de votre soutien et votre engagement
```

**Logistique**

```
Salles (1 grande salle, 2 petites salles)
Connexion internet
Sonorisation
Transports des matériels
Matériels de projection
Cocktail - Tout le monde
Eau - Tout le monde
Compute / API costs pour workshop & practicals
Indemnités repas + transport - STAFF
Indemnités - Bénévoles
```
**Communication**

```
Campagne de promotion Facebook ads & Linkedin
Nom de domaine site web
Maître de cérémonie 
Média pendant l'événement (Live stream)
Photographe
```
```
Production
Impression
```
```
Posters
Rollup
Bâche
Flyers format A6 (recto-verso)
Badges STAFF + Bénévoles
Autocollants
Photobooth
Pins - Tout le monde
Bloc note - Participants Concours
Stylos - Tout le monde
Polo - STAFF
Tee-shirt - Participants Concours + Bénévoles
```
**Lots**

```
3 gagnants Hackathon
3 équipes gagnantes Ideathon
Quizz
Sac (totebag) biodégradable
Trophée en plexiglass
Chèque cadeau 
Imprévus
```
##### Prévision des besoins

```
Sponsoring - IndabaX Madagascar 2025 9
```

## Équipe

## organisatrice

```
Pilotage
```
```
Événementiel - Workshops
```
```
Partenariat
```
```
Pilotage
```
```
Logistique
```
```
Hackathon
```
```
Keynotes - Concours
```
```
Keynotes - Concours
```
```
Posters
```
```
Wenda
```
```
Salimo
```
```
Dr. Nirilanto
```
```
Dihary
```
```
Tahina
```
```
Mendrika
```
```
Taratra
```
```
Lorenzo
```
```
Diamondra
```
```
Communication
```
```
Communication DLI
```
```
Posters
```
```
Lova
```
```
Beasy
```
```
Kristian
```
```
Sponsoring - IndabaX Madagascar 2025 10
```
**Open Community**

```
Communication
Aina Tino
Logistique
Law
```
```
Workshops
```
```
Hackathon
```
```
Partenariat
```
```
Tsilavo
```
```
Mahatoky
```
```
Dr. Lahatra
```
```
Finance
Sendrasoa
```

## Contact

# Ensemble,

# façonnons le

# futur de l'IA à

# Madagascar.

[http://www.indabaxmada.com](http://www.indabaxmada.com)

indabaxmadagascar@gmail.com

**Site web**

**Email**


